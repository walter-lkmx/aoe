@extends('layouts.app') 
@section('content') 
@php(woocommerce_content()) 
@endsection  