<div class="welcome">
	<h1>Building healthy companies</h1>
	<p>Group wellness Software as a Service (SaaS) platform empowering organizations to support healthy humans.</p>
	<a href="/subscribe" title="Subscribe Now"><span>Subscribe Now</span></a>
</div>