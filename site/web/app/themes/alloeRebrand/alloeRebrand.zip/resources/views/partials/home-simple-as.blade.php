<div class="simple-as">
	  <div class="content">
	  <h2>Simple as 1, 2, 3</h2>  
	  	  	<ul>
	  	  		<li><img src="@asset('images/icon-sign-up.svg')" alt=""> Sign Up</li>
	  	  		<li><img src="@asset('images/icon-send.svg')" alt=""> Send Invitations</li>
	  	  		<li><img src="@asset('images/icon-start.svg')" alt=""> Start</li>
	  	  		<li class="subscribe-now"><a href="/subscribe" title="Subscribe Now"><span>Subscribe Now</span></a></li>
	  	  	</ul>
	   </div>
</div>