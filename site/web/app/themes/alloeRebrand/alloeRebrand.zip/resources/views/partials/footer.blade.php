<footer class="content-info">
    <div class="width-boundaries">
        <div class="brand">
            <img src="@asset('images/alloe-logo.svg')" alt="Alloe">
        </div>
        <div class="links">
            <ul class="about">
                <li>About Alloe.io</li>
                <li><a href="">About</a></li>
                <li><a href="">Team</a></li>
                <li><a href="">Security</a></li>
            </ul>
            <ul class="get-touch">
                <li>Get in touch</li>
                <li><a href="">Contact</a></li>
                <li><a href="">Careers</a></li>
            </ul>
            <ul class="customer-service">
                <li>Customer service</li>
                <li><a href="">My account</a></li>
                <li><a href="">FAQ</a></li>
            </ul>
        </div>
    </div>
</footer>
