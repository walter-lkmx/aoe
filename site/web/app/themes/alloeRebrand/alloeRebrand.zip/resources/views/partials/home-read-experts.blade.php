<div class="read-experts">
  <img src="@asset('images/icon-write-machine.svg')" alt="">
  <h2>From our <span>experts</span></h2>  
	  <p>Read awesome recommendations from our experts in <span>nutrition, fitness, health, etc.</span></p>
	  <a href="/blog" title="">Read the blog</a>
</div>