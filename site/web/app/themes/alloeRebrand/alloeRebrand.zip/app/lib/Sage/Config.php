<?php

namespace Roots\Sage;

class Config extends \Illuminate\Config\Repository
{

}
